import java.util.ArrayList;

public class Login {
    private String email;
    private String senha;
    private String nomeDeUsuario;
    private String nome;
    private String sobrenome;
    private String empresa;
    private String telefone;
    private ArrayList<Produto> produtos;

    public Login(String email, String senha, String nomeDeUsuario, String nome, String sobrenome, String empresa, String telefone) {
        this.email = email;
        this.senha = senha;
        this.nomeDeUsuario = nomeDeUsuario;
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.empresa = empresa;
        this.telefone = telefone;
        this.produtos = new ArrayList<>();
    }

    public Login() {
        this.produtos = new ArrayList<>();
    }

    public ArrayList<Produto> getProdutos() {
        return produtos;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    public String getEmpresa() {
        return empresa;
    }

    public void setEmpresa(String empresa) {
        this.empresa = empresa;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getNomeDeUsuario() {
        return nomeDeUsuario;
    }

    public void setNomeDeUsuario(String nomeDeUsuario) {
        this.nomeDeUsuario = nomeDeUsuario;
    }

    //Método para adicionar produtos na lista de produtos do Login
    public void adicionarProdutos(ArrayList<Produto>compras){

            produtos.addAll(compras);

    }

    @Override
    public String toString() {
        return "\n\rNome: "+ this.nome+" "+this.sobrenome+
                "\n\rLogin: "+this.nomeDeUsuario+"\n\rEmail cadastrado: "
                +this.email+"\n\rEmpresa: "+this.empresa+"\n\rTelefone: "+this.telefone;
    }
}
