import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Carrinho {
    private double precoTotal;
    private int quantidadeDeItens;
    private List<Produto> produtos = new ArrayList<>();

    public Carrinho() {
    }

    public List<Produto> getProdutos() {
        return produtos;
    }

    public void setProdutos(List<Produto> prosdutos) {
        this.produtos = prosdutos;
    }

    public double getPrecoTotal() {
        return precoTotal;
    }

    public int getQuantidadeDeItens() {
        return quantidadeDeItens;
    }

    //Método para adicionar um produto na lista de produtos do carrinho
    public void addProduto(Produto produto) {
        this.produtos.add(produto);
        //Atualiza o preço total do carrinho após adicionar um produto
        atualizarPrecoTotal();

    }

    //Método para atualizar o preço total do carrinho
    private void atualizarPrecoTotal() {
        this.precoTotal = this.produtos.stream()
                .mapToDouble(Produto::getPreco).sum();
    }

    @Override
    public String toString() {

        return "Carrinho:\n\r"+"Valor total: "+ this.precoTotal+
                "\n\rQuantidade de itens no carrinho: "
                +this.quantidadeDeItens+"\n\rProdutos: "+this.produtos ;
    }



    public int size() {
        return this.quantidadeDeItens = produtos.size();
    }
}
