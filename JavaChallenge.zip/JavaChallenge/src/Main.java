
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {


        menu();

    }

    public static void menu() {
        var opcao = 0;
        //Variável para armazenar os Logins cadastrados
        var logins = new ArrayList<Login>();
        while (opcao != 4) {
            System.out.println("1.Cadastrar\n\r2.Listar todos os cadastros\r\n3.Fazer login\n\r4.Sair");
            var scanner = new Scanner(System.in);
            opcao = scanner.nextInt();
            scanner.nextLine();
            if (opcao == 1) {
                //Chama o método para cadastrar um novo Login e adiciona o novo Login na lista de Logins
                logins.add(criarLogin(logins));
            } else if (opcao == 2) {
                //Mostra no Console os Logins cadastrados
                if(!logins.isEmpty()) {
                    System.out.println("Logins cadastrados:\n" + logins);
                }
                //Se não houver nenhum cadastro
                else {
                    System.out.println("Nenhum cadastro foi realizado");
                }
            } else if (opcao == 3) {
                var continuar = 0;
                if (!logins.isEmpty()) {
                    while (true) {
                        //Pega as informações de login
                        System.out.println("Digite seu username ou email cadastrado: ");
                        String username = scanner.nextLine();
                        System.out.println("Digite a senha: ");
                        String senha = scanner.nextLine();
                        //Verifica o login usando o método verificarLogin
                        if (verificarLogin(logins, username, senha)) {
                            //Salva em uma variável o login que foi logado
                            Login loginLogado = (saberLogin(logins, username, senha));
                            System.out.println("Login efetuado com sucesso");
                            while (true) {
                                System.out.println("1. Voltar ao menu principal\n\r" +
                                        "2. Ir para o menu de compras\n\r" +
                                        "3. Visualizar meus produtos");
                                var escolha = scanner.nextInt();
                                scanner.nextLine();

                                if (escolha == 1) {
                                    break;
                                } else if (escolha == 2) {
                                    //Salva as compras realizadas em uma variável
                                    var compras = comprar();
                                    for (Login l : logins) {

                                        if (l.equals(loginLogado)) {
                                            if (compras != null) {
                                                //Adiciona as compras na lista de produtos do usuário
                                                l.adicionarProdutos(compras);
                                            }

                                        }

                                    }

                                } else if (escolha == 3) {
                                    for (Login l : logins) {

                                        if (l.equals(loginLogado)) {
                                            //Verifica se existe algun produto na lista de produtos do usuário
                                            if (!l.getProdutos().isEmpty()) {
                                                //Mostra no console os produtos que existem na lista de produtos do usuário
                                                System.out.println("Seus produtos:");
                                                for (Produto p : l.getProdutos()) {
                                                    System.out.println(p.getNome());
                                                }
                                            } else {
                                                System.out.println("Você ainda não possui nenhum produto");
                                            }

                                        }

                                    }

                                } else {
                                    System.out.println("opção inválida");
                                }

                            }
                            break;

                        } else {
                            System.out.println("Username ou senha inválido\n\r1. Voltar ao menu principal\n\rQualquer outro número para tentar novamente");
                            continuar = scanner.nextInt();
                            scanner.nextLine();
                            if (continuar == 1) {
                                break;
                            } else {
                                continue;
                            }


                        }
                    }
                } else {
                    System.out.println("Nenhum cadastro registrado, crie um cadastro  para realizar o login");

                }

            } else if (opcao == 4) {
                System.out.println("Encerrando o programa");
            } else {
                System.out.println("Digite um número de 1 à 4, sendo 4 para fechar o programa");
            }
        }
    }

        // Método para verificar se o Login que o usuário inseriu está correto
    public static boolean verificarLogin(ArrayList<Login> logins, String username, String senha) {
        for (Login l : logins) {

            //Verifica se o username inserido é igual ao nome de usuário ou email cadastrado
            if (l.getNomeDeUsuario().equals(username) || l.getEmail().equals(username)) {
                //Verifica se a senha inserida corresponde a senha cadastrada
                if (l.getSenha().equals(senha)) {
                    return true;

                }
            }

        }
        return false;
    }

        //Método para poder salvar em uma variável o Login
    public static Login saberLogin(ArrayList<Login> logins, String username, String senha) {
        for (Login l : logins) {

            if (l.getNomeDeUsuario().equals(username) || l.getEmail().equals(username)) {
                if (l.getSenha().equals(senha)) {

                    //retorna o Login que corresponde ao username e senha inseridos
                    return l;

                }
            }

        }
        return null;
    }

        //Método para realizar um cadastro
    public static Login criarLogin(ArrayList<Login> logins) {

        var scanner = new Scanner(System.in);
        Login novoLogin = new Login();
        System.out.println("Nome: ");
        novoLogin.setNome(scanner.nextLine());
        System.out.println("Sobrenome: ");
        novoLogin.setSobrenome(scanner.nextLine());
        System.out.println("Empresa: ");
        novoLogin.setEmpresa(scanner.nextLine());
        System.out.println("Telefone ou celular: ");
        novoLogin.setTelefone(scanner.nextLine());

        while (true) {
            System.out.println("Digite um nome de usuário: ");
            var username = scanner.nextLine();
            var achou = 0;
            if (!logins.isEmpty()) {
                for (Login l : logins) {

                    //Confere se o nome de usuário já existe
                    if (l.getNomeDeUsuario().equals(username)) {
                        System.out.println("Este nome de usuário já existe");
                        achou = 1;
                        break;
                    }
                }
            }
            if (achou == 0) {
                novoLogin.setNomeDeUsuario(username);
                break;
            }
        }

        while (true) {
            System.out.println("Digite um email válido: ");
            var email = scanner.nextLine();
            var achou = 0;
            if (!logins.isEmpty()) {
                for (Login l : logins) {
                    //Confere se o email já foi cadastrado
                    if (l.getEmail().equals(email)) {
                        System.out.println("Este email já foi cadastrado");
                        achou = 1;
                        break;
                    }
                }
            }
            if (achou == 0) {
                novoLogin.setEmail(email);
                break;
            }
        }
        System.out.println("Crie uma senha: ");
        novoLogin.setSenha(scanner.nextLine());
        //Retorna o Login cadastrado
        return novoLogin;
    }

    //Método para realizar a compra de produtos
    public static ArrayList<Produto> comprar() {
        List<Produto> produtos = Arrays.asList(
                new Produto("Data Cloud", 165.00, "Desbloqueie dados de clientes e obtenha insights acionáveis em tempo real, em escala." +
                        " Economize tempo e dinheiro enquanto aumenta sua receita com o Data Cloud."),
                new Produto("Marketing", 1000.00, "Atraia clientes, Gere mais engajamento, " +
                        "Construa relações duradouras.\n" +
                        "Tudo isso graças ao marketing digital baseado em dados."),
                new Produto("Vendas", 165.00,
                        "Eficiência máxima com automação, dados e inteligências melhores. Como? Com automação da força de vendas impulsionada por IA."),
                new Produto("Tableau", 1000.00, "Tome decisões acompanhando a velocidade de mudanças para proporcionar sucesso imediato\n" +
                        "Descubra as conexões entre dados, insights e melhores resultados de negócios com a análise completa."));


        var scanner = new Scanner(System.in);
        var carrinho = new Carrinho();
        var opcao = 0;
        var escolha = 0;


        while (true) {
            System.out.println("\n\r=====Bem Vindo(a) ao menu de compras da SalesForce=====\n\r" +

                    "1. Saber mais sobre os produtos\n\r" +
                    "2. Adicionar produtos ao carrinho\n\r" +
                    "3. Ver carrinho\n\r" +
                    "4. Limpar carrinho\n\r" +
                    "5. Sair\n\r" +
                    "Digite o número da opção que deseja realizar: ");
            opcao = scanner.nextInt();

            if (opcao == 1) {
                System.out.println("\n\r=====Conheça nossos produtos e serviços=====");
                for (var Produto : produtos) {
                    System.out.println("\n\r" + Produto.toString());
                }
            } else if (opcao == 2) {
                while (true) {
                    System.out.println("\n\rEscolha o produto que deseja adicionar ao carrinho:\n\r" +
                            "0.Data Cloud\n\r" +
                            "1.Marketing\n\r" +
                            "2.Vendas\n\r" +
                            "3.Tableau\n\r" +
                            "4.Voltar para o menu principal");
                    escolha = scanner.nextInt();
                    //Adiciona o produto escolhido ao carrinho
                    if (escolha == 1 || escolha == 0 || escolha == 2 || escolha == 3) {
                        System.out.println(produtos.get(escolha).adicionarAoCarrinho());
                        carrinho.addProduto(produtos.get(escolha));

                    } else if (escolha == 4) {
                        break;
                    } else {
                        System.out.println("\n\ropção iválida digite um número de 0 à 4");

                    }
                }
            } else if (opcao == 3) {
                if (carrinho.size() > 0) {

                    System.out.println("\n\rProdutos no carrinho:");
                    //Mostra no console os produtos que estão no carrinho
                    carrinho.getProdutos().stream().map(produto -> produto.getNome()).forEach(System.out::println);
                    //Mostra o preço total do carrinho
                    System.out.println("Valor total: " + carrinho.getPrecoTotal());
                    System.out.println("Deseja finalizar a compra?\n\r" +
                            "1. Sim\n\r" +
                            "2. Não");
                    escolha = scanner.nextInt();
                    if (escolha == 1) {
                        System.out.println("Compra realizada com sucesso!");
                        //retorna a lista de produtos que foram comprados
                        return (ArrayList<Produto>) carrinho.getProdutos();
                    } else if (escolha == 2) {
                        continue;
                    } else {
                        System.out.println("Opção inválida");
                    }

                } else {
                    System.out.println("\n\rO carrinho está vazio");
                }
            } else if (opcao == 4) {
                //Remove todos os produtos do carrinho
                carrinho.getProdutos().clear();
                System.out.println("\n\rO carrinho agora está vazio");
            } else if (opcao == 5) {
                System.out.println("Encerrando o programa");
                //Retorna null, pois a compra não foi finalizada
                return null;
            } else {
                System.out.println("\n\ropção inválida digite um número de 1 à 5");
            }
        }

    }
}
