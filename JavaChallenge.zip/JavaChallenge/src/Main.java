
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        var scanner = new Scanner(System.in);

        List<Produto> produtos = Arrays.asList(
                new Produto("Data Cloud", 165.00, "Desbloqueie dados de clientes e obtenha insights acionáveis em tempo real, em escala." +
                        " Economize tempo e dinheiro enquanto aumenta sua receita com o Data Cloud."),
                new Produto("Marketing", 1000.00, "Atraia clientes, Gere mais engajamento, " +
                        "Construa relações duradouras.\n" +
                        "Tudo isso graças ao marketing digital baseado em dados."),
        new Produto("Vendas", 165.00,
                "Eficiência máxima com automação, dados e inteligências melhores. Como? Com automação da força de vendas impulsionada por IA."),
        new Produto("Tableau",1000.00,"Tome decisões acompanhando a velocidade de mudanças para proporcionar sucesso imediato\n" +
                "Descubra as conexões entre dados, insights e melhores resultados de negócios com a análise completa." ));
        List<Produto> carrinho = new ArrayList<Produto>();

        var opcao = 0;
        var escolha = 0;


     while (true) {
         System.out.println("\n\r=====Bem Vindo(a) ao menu de compras da SalesForce=====\n\r"+

                 "1. Saber mais sobre os produtos\n\r" +
                 "2. Adicionar produtos ao carrinho\n\r" +
                 "3. Ver carrinho\n\r" +
                 "4. Limpar carrinho\n\r" +
                 "5. Sair\n\r"+
                 "Digite o número da opção que deseja realizar: ");
         opcao = scanner.nextInt();

         if (opcao == 1) {
             System.out.println("\n\r=====Conheça nossos produtos e serviços=====");
             for (var Produto : produtos) {
                 System.out.println("\n\r"+Produto.toString());
             }
         } else if (opcao == 2) {
             while (true) {
                 System.out.println("\n\rEscolha o produto que deseja adicionar ao carrinho:\n\r" +
                         "0.Data Cloud\n\r" +
                         "1.Marketing\n\r" +
                         "2.Vendas\n\r"+
                         "3.Tableau\n\r"+
                         "4.Voltar para o menu principal");
                 escolha = scanner.nextInt();

                 if (escolha == 1 || escolha == 0 || escolha == 2 || escolha == 3) {
                     System.out.println(produtos.get(escolha).adicionarAoCarrinho());
                     carrinho.add(produtos.get(escolha));

                 } else if (escolha == 4) {
                     break;
                 } else {
                     System.out.println("\n\ropção iválida digite um número de 0 à 4");

                 }
             }
         } else if (opcao == 3) {
             if (carrinho.size() > 0) {
                 System.out.println("\n\rProdutos no carrinho:");
                 carrinho.stream().map(produto -> produto.getNome()).forEach(System.out::println);
                 System.out.println("Valor total: ");
                 double precototal = carrinho.stream().mapToDouble(Produto::getPreco).sum();
                 System.out.println(precototal);
             } else {
                 System.out.println("\n\rO carrinho está vazio");
             }
         } else if (opcao == 4) {
             carrinho.clear();
             System.out.println("\n\rO carrinho agora está vazio");
         } else if (opcao == 5) {
             System.out.println("Encerrando o programa");
             break;
         } else {
             System.out.println("\n\ropção inválida digite um número de 1 à 5");
         }


     }

    }
}